int main(){
	int a=3;
	int b=2;
	b=b*a;
	b=b*a;
	return 0;
}