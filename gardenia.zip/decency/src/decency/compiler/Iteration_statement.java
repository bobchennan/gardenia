package decency.compiler;

import decency.compiler.Symbol;

public abstract class Iteration_statement extends Statement {
}