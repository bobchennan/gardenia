package decency.compiler;

import decency.compiler.Symbol;

public enum Assignment_operator {
	ASSIGN, MULASS, ADDASS, SUBASS
}