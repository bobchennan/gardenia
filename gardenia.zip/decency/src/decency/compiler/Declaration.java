package decency.compiler;

import decency.compiler.Symbol;

public class Declaration {
	public Init_declarators _init = null;
	
	public Declaration(Init_declarators y){
		_init = y;
	}
}