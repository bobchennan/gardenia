package decency.compiler;

import decency.compiler.Symbol;

public abstract class Primary_expression extends Postfix_expression {
}