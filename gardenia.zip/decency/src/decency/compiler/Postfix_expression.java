package decency.compiler;

import decency.compiler.Symbol;

public abstract class Postfix_expression {
}