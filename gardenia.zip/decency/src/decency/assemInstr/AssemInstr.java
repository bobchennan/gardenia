package decency.assemInstr;


public abstract class AssemInstr {
}
