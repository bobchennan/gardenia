package decency.assemInstr;

public abstract class Operand {
	
}
