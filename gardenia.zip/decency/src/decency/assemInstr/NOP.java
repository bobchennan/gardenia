package decency.assemInstr;

public class NOP extends AssemInstr {
	public NOP(){}
	
	@Override
	public String toString() {
		return "nop";
	}
}
