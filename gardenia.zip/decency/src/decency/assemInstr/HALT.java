package decency.assemInstr;

public class HALT extends AssemInstr {
	public HALT(){}
	
	@Override
	public String toString() {
		return "nop";
	}
}
